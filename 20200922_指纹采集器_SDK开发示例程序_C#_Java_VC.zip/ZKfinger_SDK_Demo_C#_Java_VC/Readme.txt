setup.exe
	ZKFinger SDK_Ver3.0.0.1 setup
ZKFinger SDK_chs.pdf
	Chinese ZKFinger SDK Development Guide
ZKFinger SDK_en.pdf
	English ZKFinger SDK Development Guide
Sample
	Source code of VC/C#/Java sample