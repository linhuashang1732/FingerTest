//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Sample.rc
//
#define IDD_SAMPLE_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDC_STATIC_DRAWAREA             1000
#define IDC_EDT_PROMPT                  1001
#define IDC_EDT_QUALITY                 1002
#define IDC_RADIO10                     1004
#define IDC_BTN_INIT                    1005
#define IDC_COMBO_INDEX                 1006
#define IDC_BTN_OPEN                    1007
#define IDC_BTN_ENROLL                  1008
#define IDC_BTN_IDENTIFY                1009
#define IDC_BTN_GREEN                   1010
#define IDC_BTN_RED                     1011
#define IDC_BTN_BEEP                    1012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
