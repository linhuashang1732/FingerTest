#include "stdafx.h"

#ifdef __cplusplus
extern "C"
{
#endif

int WriteBitmap(BYTE *buffer, int Width, int Height, char *file);

BYTE *LoadFile(const char *FileName, int *size);

int SaveToFile(const char *fileName, void *buffer, int size);
int logClose();
int logMsg(char *fmt, ...);

int ReadBitmap(BYTE *p, BYTE *buffer, int *Width, int *Height);

int LoadBitmapFile(const char *FileName, BYTE *buffer, int *Width, int *Height);

int DumpData(BYTE *data, int dataSize);

HBITMAP BuildImage(BYTE *image, int width, int height);



#ifdef __cplusplus
}
#endif