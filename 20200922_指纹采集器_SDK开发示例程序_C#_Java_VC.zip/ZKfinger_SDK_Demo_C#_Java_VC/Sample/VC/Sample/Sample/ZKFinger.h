/****************************************************
	author	: xisy 
	date	: 2011.10.08
                                                      
 Copyright (C) 2011-2011, ZKSoftware Inc.               
                                                      
*************************************************/
#include <stdio.h>

#define THRESHOLD_MIDDLE 55 // 1:N recommendation threshold
#define THRESHOLD_LOW 35    // 1:1 recommendation threshold

typedef HANDLE (__stdcall *T_BIOKEY_INIT)(int License, WORD *isize, BYTE *Params, BYTE *Buffer, int ImageFlag);
typedef int (__stdcall *T_BIOKEY_CLOSE)(HANDLE Handle);
typedef int (__stdcall *T_BIOKEY_SET_PARAMETER)(HANDLE Handle, int paramCode, int paramValue);
typedef int (__stdcall *T_BIOKEY_MATCHINGPARAM)(HANDLE Handle,  int speed, int threshold);
typedef int (__stdcall *T_BIOKEY_GETLASTQUALITY)(HANDLE Handle);
typedef int (__stdcall *T_BIOKEY_GETLASTERROR)(HANDLE Handle);
typedef int (__stdcall *T_BIOKEY_EXTRACT)(HANDLE Handle, BYTE* PixelsBuffer, BYTE *Template, int PurposeMode);
typedef int (__stdcall *T_BIOKEY_GENTEMPLATE)(HANDLE Handle, BYTE *Templates[], int TmpCount, BYTE *GTemplate);
typedef int (__stdcall *T_BIOKEY_GENTEMPLATE_SP)(HANDLE Handle, BYTE *Template1, BYTE *Template2, BYTE *Template3, int TmpCount, BYTE *GTemplate);
typedef int (__stdcall *T_BIOKEY_DB_ADD)(HANDLE Handle,  int TID, int TempLength, BYTE *Template);
typedef int (__stdcall *T_BIOKEY_DB_DEL)(HANDLE Handle, int TID);
typedef int (__stdcall *T_BIOKEY_DB_COUNT)(HANDLE Handle);
typedef int (__stdcall *T_BIOKEY_DB_CLEAR)(HANDLE Handle);
typedef int (__stdcall *T_BIOKEY_IDENTIFYTEMP)(HANDLE Handle, BYTE *Template, int *TID, int *Score);
typedef int (__stdcall *T_BIOKEY_VERIFY)(HANDLE handle, BYTE *Template1, BYTE *Template2);


T_BIOKEY_INIT BIOKEY_INIT;
T_BIOKEY_CLOSE BIOKEY_CLOSE;
T_BIOKEY_SET_PARAMETER BIOKEY_SET_PARAMETER;
T_BIOKEY_MATCHINGPARAM BIOKEY_MATCHINGPARAM;
T_BIOKEY_GETLASTQUALITY BIOKEY_GETLASTQUALITY;
T_BIOKEY_GETLASTERROR BIOKEY_GETLASTERROR;
T_BIOKEY_EXTRACT BIOKEY_EXTRACT;
T_BIOKEY_GENTEMPLATE BIOKEY_GENTEMPLATE;
T_BIOKEY_GENTEMPLATE_SP BIOKEY_GENTEMPLATE_SP;
T_BIOKEY_DB_ADD BIOKEY_DB_ADD;
T_BIOKEY_DB_DEL BIOKEY_DB_DEL;
T_BIOKEY_DB_COUNT BIOKEY_DB_COUNT;
T_BIOKEY_DB_CLEAR BIOKEY_DB_CLEAR;
T_BIOKEY_IDENTIFYTEMP BIOKEY_IDENTIFYTEMP;
T_BIOKEY_VERIFY BIOKEY_VERIFY;