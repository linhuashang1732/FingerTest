// SampleDlg.h : header file
//

#pragma once

#define MESSAGE_FP_RECEIVED		WM_USER + 1

// CSampleDlg dialog
class CSampleDlg : public CDialog
{
// Construction
public:
	CSampleDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_SAMPLE_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();

	afx_msg LRESULT OnFPReceived(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedBtnInit();
	afx_msg void OnBnClickedBtnOpen();
	afx_msg void OnClose();
	afx_msg void OnBnClickedBtnEnroll();
	afx_msg void OnBnClickedBtnIdentify();
	afx_msg void OnBnClickedBtnGreen();
	afx_msg void OnBnClickedBtnRed();
	afx_msg void OnBnClickedBtnBeep();
};
