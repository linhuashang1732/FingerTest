package test;

import org.xvolks.jnative.exceptions.NativeException;

import com.zkteco.*;

public class Test {
	public static int byte2Int(byte[] b) {
		return (int) (b[0] & 0xFF) + (int) ((b[1] & 0xFF) << 8)
				+ (int) ((b[2] & 0xFF) << 16) + (int) ((b[3] & 0xFF) << 24);
	}

	public static int capture(int devHandle, byte[] imageBuffer,
			int imageBufferSize) throws InterruptedException, NativeException,
			IllegalAccessException {
		while (true) {
			int ret = ZKFPCap.sensorCapture(devHandle, imageBuffer,
					imageBufferSize);
			if (ret > 0) {
				System.out.println("Captured an image");
				return ret;
			}
			Thread.sleep(30);
		}
	}

	/**
	 * @param args
	 * @throws InterruptedException
	 * @throws IllegalAccessException
	 * @throws NativeException
	 */
	public static void main(String[] args) throws InterruptedException,
			NativeException, IllegalAccessException {

		byte[] paramValue = new byte[64];
		byte[] template = new byte[2048];
		byte[] imageBuffer = null;
		int[] paramLen = { paramValue.length };
		int devHandle = 0;
		int fpHandle = 0;
		int width = 0;
		int height = 0;
		int bufferSize = 0;
		String manufacturer = null;
		String productName = null;
		String sn = null;
		int ret = ZKFPCap.sensorInit();
		if (0 != ret) {
			System.out.println("sensorInit failed ret=" + ret);
			return;
		}

		System.out.println("sensorCount=" + ZKFPCap.sensorGetCount()
				+ ", version=" + ZKFPCap.sensorGetVersion());

		devHandle = ZKFPCap.sensorOpen(0);
		if (devHandle <= 0) {
			System.out.println("sensorOpen failed");
			ZKFPCap.sensorFree();
			return;
		}

		ret = ZKFPCap.sensorGetParameter(devHandle, 1, paramValue, paramLen);
		width = byte2Int(paramValue);

		paramLen[0] = paramValue.length;
		ret = ZKFPCap.sensorGetParameter(devHandle, 2, paramValue, paramLen);
		height = byte2Int(paramValue);

		paramLen[0] = paramValue.length;
		ret = ZKFPCap.sensorGetParameter(devHandle, 106, paramValue, paramLen);
		bufferSize = byte2Int(paramValue);

		paramLen[0] = paramValue.length;
		ret = ZKFPCap.sensorGetParameter(devHandle, 1101, paramValue, paramLen);
		manufacturer = new String(paramValue, 0, paramLen[0]);

		paramLen[0] = paramValue.length;
		ret = ZKFPCap.sensorGetParameter(devHandle, 1102, paramValue, paramLen);
		productName = new String(paramValue, 0, paramLen[0]);

		paramLen[0] = paramValue.length;
		ret = ZKFPCap.sensorGetParameter(devHandle, 1103, paramValue, paramLen);
		sn = new String(paramValue, 0, paramLen[0]);

		System.out.println("width=" + width + ", height=" + height + ", size="
				+ bufferSize);
		System.out.println(manufacturer);
		System.out.println(productName);
		System.out.println(sn);

		imageBuffer = new byte[bufferSize];
		fpHandle = ZKFinger10.BIOKEY_INIT(width, height);
		if (fpHandle == 0) {
			System.out
					.println("Error to open fingerprint recognition library!");
			ZKFPCap.sensorClose(devHandle);
			ZKFPCap.sensorFree();
			return;
		}
		// Set allow angle of Press Finger
		ZKFinger10.BIOKEY_SET_PARAMETER(fpHandle, 4, 180);

		System.out
				.println("Start Enrollment, press a finger on the sensor ...");
		ret = capture(devHandle, imageBuffer, bufferSize);
		ret = ZKFinger10.BIOKEY_EXTRACT(fpHandle, imageBuffer, template, 1);
		if (ret > 0) {
			ret = ZKFinger10.BIOKEY_DB_ADD(fpHandle, 10, ret, template);
			System.out
					.println(String
							.format("\tret=%d, save the fingerprint template as 10. enrolled count=%d",
									ret, ZKFinger10.BIOKEY_DB_COUNT(fpHandle)));
		}
		System.out
				.println("Start Enrollment, press an other finger on the sensor ...");
		ret = capture(devHandle, imageBuffer, bufferSize);
		ret = ZKFinger10.BIOKEY_EXTRACT(fpHandle, imageBuffer, template, 1);
		if (ret > 0) {
			ret = ZKFinger10.BIOKEY_DB_ADD(fpHandle, 20, ret, template);
			System.out
					.println(String
							.format("\tret=%d, save the fingerprint template as 20. enrolled count=%d",
									ret, ZKFinger10.BIOKEY_DB_COUNT(fpHandle)));
		}

		int times = 0;
		while (times++ < 10) {
			System.out
					.println("\nIdentification, press a finger on the sensor ...");
			ret = capture(devHandle, imageBuffer, bufferSize);
			int[] id = new int[1];
			int[] score = new int[1];
			ret = ZKFinger10.BIOKEY_IDENTIFY(fpHandle, imageBuffer, id, score);
			System.out.println(String.format("\tret=%d, id=%d, score=%d", ret,
					id[0], score[0]));
		}

		ZKFPCap.sensorClose(devHandle);
		ZKFPCap.sensorFree();
		ZKFinger10.BIOKEY_CLOSE(fpHandle);

		System.out.println("Exit");
	}
}
