﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.OperationClass
{
    class balance_3
    {
        /// <summary>
        /// 直方图均衡化 直方图均衡化就是对图像进行非线性拉伸，重新分配图像像素值，使一定灰度范围内的像素数量大致相同
        /// 增大对比度，从而达到图像增强的目的。是图像处理领域中利用图像直方图对对比度进行调整的方法
        /// </summary>
        /// <param name="srcBmp">原始图像</param>
        /// <param name="dstBmp">处理后图像</param>
        /// <returns>处理成功 true 失败 false</returns>
        public static bool Balance(Bitmap srcBmp, out Bitmap dstBmp)
        {
            if (srcBmp == null)
            {
                dstBmp = null;
                return false;
            }
            int[] histogramArray = new int[256];//各个灰度级的像素数R
            dstBmp = new Bitmap(srcBmp);
            dstBmp = new Bitmap(dstBmp.Width, dstBmp.Height, PixelFormat.Format8bppIndexed);
            Rectangle rt = new Rectangle(0, 0, srcBmp.Width, srcBmp.Height);
            BitmapData bmpData = srcBmp.LockBits(rt, ImageLockMode.ReadOnly, PixelFormat.Format8bppIndexed);
            unsafe
            {


                byte* ptr;
                //统计各个灰度级的像素个数
                for (int i = 0; i < bmpData.Height; i++)
                {
                    ptr = (byte*)bmpData.Scan0 + i * bmpData.Stride;
                    for (int j = 0; j < bmpData.Width; j++)
                    {
                        histogramArray[*ptr]++;
                        ptr++;
                    }
                }
                //计算灰度的均值和方差
                double dMean = 0;
                for (int i = 0; i < 255; i++)
                {
                    dMean += i * histogramArray[i];
                }
                dMean = (dMean / (bmpData.Height * bmpData.Width));
                double dSigma = 0; for (int i = 0; i < 255; i++)
                {
                    dSigma += histogramArray[i] * (i - dMean) * (i - dMean);
                }
                dSigma /= (bmpData.Height * bmpData.Width);
                dSigma = System.Math.Sqrt(dSigma);
                //均衡化操作
                double dMean0 = 128, dSigma0 = 128;
                double dCoeff = dSigma0 / dSigma;

                byte value = 0;
                ptr = (byte*)(bmpData.Scan0);
                for (int i = 0; i < bmpData.Height; i++)
                {
                    for (int j = 0; j < bmpData.Width; j++)
                    {
                        value = (byte)(*ptr);
                        value = (byte)(dMean0 + dCoeff * (value- dMean0));
                        if (value < 0)
                        {
                            value = 0;
                        }
                        else if (value > 255)
                        {
                            value = 255;
                        }
                        *ptr = value;
                        ptr += 1;
                    }
                    ptr += bmpData.Stride - bmpData.Width;
                }
                for (int i = 0; i < 256; i++)
                {
                    dstBmp.Palette.Entries[i] = Color.FromArgb(i, i, i);
                }

            }
            srcBmp.UnlockBits(bmpData);

            return true;
        }
    }
}


