﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.BaseOper;
using static System.Math;
using static WpfApp1.Step.Step11;

namespace WpfApp1.Step
{
    class Step_All
    {
        public static void step_all(Bitmap bm, out MINUTIAE[] minutiaes,out int count)
        {
            //保存各步运行的结果并且参与下一步图像处理
            Bitmap bt;
            //第二步：中值滤波,返回滤波后的bmp
            bt = Step2.Step_2(bm);

            //第三步：均衡化
            bt = Step3.Step_3(bt);

            ////注：第三步之后若无强调，后续步骤操作的bmp均为均衡化的结果图像
            //第四步：脊线方向计算：
            //参数：bmp，float[]fDirc：保存方向数据；
            //输出：方向数据：fDirc[]
            float[] fDirc;
            Step4.Step_4(bt, out fDirc);

            //第五步：脊线频率计算：
            //参数：Bitmap bmp：第三步均衡化的结果图像,float[]fDir：第四步的方向数据,
            //out float[]fFreqGet：本次的输出结果
            float[] fFreqGet;
            Step5.Step_5(bt, fDirc, out fFreqGet);

             //第六步：掩码计算
            //参数：Bitmap bmp, float[] fDir, float[] fFreqGet：第五步结果
            //out byte[] ucMask：本次输出结果
            byte[] ucMask;
            Step6.Step_6(bt, fDirc, fFreqGet, out ucMask);

            //第七步：Gabor滤波
            //参数：Bitmap bmp, float[] fDir, float[] fFreqGet, byte[] ucMask,
            //out byte[]ucImgEnhanced
            byte[] ucImgEnhanced;
            Step7.Step_7(bt, fDirc, fFreqGet, ucMask, out ucImgEnhanced);

            //第八步：二值化
            //参数：Bitmap bmp,byte uThreshold：阈值，自己确定,out byte[]ucBinImage
            byte[] ucBinImage;
            Step8.Step_8(bt, 128,out ucBinImage);

            //第九步：细化
            //Bitmap bmp, byte[] ucBinImage, out byte[]ucThinnedImage,int count:迭代次数，自定义
            byte[] ucThinnedImage;
            Step9.Step_9(bt, ucBinImage, out ucThinnedImage, 3);

            //第十步：特征提取
            //Bitmap bmp, byte[] ucThinImg, out byte[] ucMinuImg,out int count：特征点数量
            byte[] ucMinuImg;
            count = 0;
            Step10.Step_10(bt, ucThinnedImage, out ucMinuImg, out count);

            //第十一步
            //Bitmap bmp, byte[] thinData, byte[] minuData, out MINUTIAE[] minutiaes, ref int minuCount
            
            Step11.Step_11(bt,ucThinnedImage,ucMinuImg,out minutiaes,ref count);


               

        }

    }
}
