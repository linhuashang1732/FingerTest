﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.BaseOper;

namespace WpfApp1.Step
{
    class Step10
    {
        public static Bitmap Step_10(Bitmap bmp, byte[] ucThinImg, out byte[] ucMinuImg,out int count)//bmp：均衡化的图像
        {
            int w = bmp.Width;
            int h = bmp.Height;

           Extract(w, h, ucThinImg,out ucMinuImg,out count);
            byte[] bytesCopy = new byte[w * h];
            for (int i = 0; i < bytesCopy.Length; i++)
            {
                if (ucMinuImg[i] == 0)
                {
                    bytesCopy[i] = 0;
                }
                else
                {
                    bytesCopy[i] = 255;
                }
            }
            Bitmap bm = BaseClass.BuiltGrayBitmap(bytesCopy, bmp);
            return bm;

        }

        private static void Extract(int w, int h, byte[] ucThinImg, out byte[] ucMinuImg, out int count)
        {
          int pUp, pDown, pImg;
            byte x1, x2, x3, x4, x5, x6, x7, x8;
            int nc;//八邻点中黑点数量
            ucMinuImg = new byte[w * h];
            count = 0;
            //遍历源图提取特征
            for(int i = 1; i < h - 1; i++)//逐行遍历
            {
                pUp =(i - 1) * w;
                pImg=i* w;
                pDown = (i + 1) * w;
                for(int j = 1; j < w - 1; j++)//逐列遍历
                {
                    pUp++;
                    pImg++;
                    pDown++;
                    if (ucThinImg[pImg] == 0)
                    {
                        continue;
                    }
                    //获取3*3邻域窗口内9个像素的灰度值
                    x6 = ucThinImg[pUp - 1];
                    x5 = ucThinImg[pImg - 1];
                    x4 = ucThinImg[pDown - 1];

                    x7 = ucThinImg[pUp];
                    x3 = ucThinImg[pDown];

                    x8 = ucThinImg[pUp + 1];
                    x1 = ucThinImg[pImg + 1];
                    x2 = ucThinImg[pDown + 1];

                    //统计八邻点黑点数
                    nc = (byte)(x1 + x2 + x3 + x4 + x5 + x6 + x7 + x8);

                    //特征点判断
                    if (nc == 1)//端点
                    {
                        ucMinuImg[i * w + j] = 1;
                        ++count;//特征点数量+1
                    }
                    else if (nc == 3)
                    {
                        ucMinuImg[i * w + j] = 3;
                        ++count;//特征点数量+1
                    }
                }
            }
        }
    }
}
