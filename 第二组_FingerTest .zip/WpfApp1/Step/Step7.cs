﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.BaseOper;
using static System.Math;
namespace WpfApp1.Step
{
    class Step7
    {
        public static Bitmap Step_7(Bitmap bmp, float[] fDir, float[] fFreqGet, byte[] ucMask,out byte[]ucImgEnhanced)//bmp：均衡化的图像
        {
            byte[] bytes = BaseClass.BmpToByte(bmp);
            int w = bmp.Width;
            int h = bmp.Height;
            ucImgEnhanced = new byte[w * h];
            GaborEnhance(bytes, fDir, fFreqGet, ucMask,w,h, out ucImgEnhanced);
            Bitmap bm = BaseClass.BuiltGrayBitmap(ucImgEnhanced, bmp);
            return bm;

        }
        public static void GaborEnhance(byte[]bytes,float[]fDir,float[]fFreq,byte[]ucMask,int w,int h,out byte[] ucImgEnhanced)
        {
            const float PI = 3.141592654f;
            ucImgEnhanced = new byte[w * h];
            int i, j, u, v;
            int wg2 = 5;//11*11的Gabor滤波器，半边长5
            float sum, f, g;
            float x2, y2;
            float dx2 =(float)(1.0/(4.0*4.0));
            float dy2 = (float)(1.0 / (4.0 * 4.0));
           
            //Gabor滤波
            for(j=wg2;j<h-wg2;j++)//逐行遍历，除边缘
            {
                for (i = wg2; i< w - wg2; i++)//逐列遍历，除边缘
                {
                    int index = i + j * w;
                    //跳过背景点
                     if(ucMask[index]==0)//掩码为0表示背景点
                    {
                        continue;
                    }
                    //获取当前像素的方向hepinlv
                    g = fDir[index];
                    f = fFreq[index];
                    g += PI / 2;

                    //对当前像素进行Gabor滤波
                    sum = 0.0f;
                    for(v = -wg2; v <= wg2; v++)
                    {
                        for (u = -wg2; u <= wg2; u++)
                        {
                            x2 = (float)(-u * Sin(g) + v * Cos(g));
                            y2 = (float)(u * Cos(g) + v * Sin(g));
                            sum +=(float)( Exp(-0.5 * (x2 * x2 * dx2 + y2 * y2 * dy2)) * Cos(2 * PI * x2 * f) * bytes[(i - u) + (j - v) * w]);
                        }
                    }
                    //边界值处理
                    if (sum > 255.0f)
                    {
                        sum = 255.0f;
                    }
                    if (sum <= 0.0f)
                    {
                        sum = 0.0f;
                    }
                    //得到当前像素的滤波结果
                    ucImgEnhanced[i + j * w] = (byte)sum;
                }
            }

          
        }
    }
}
