﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Math;
using static WpfApp1.Step.Step11;

namespace WpfApp1.Step
{
    class Step13
    {
        /// <summary>
        /// 构建特征点相邻关系,返回值-1，表示失败，0表示成功
        /// </summary>
        /// <param name="minutiae"></param>
        /// <param name="minuCount"></param>
        /// <returns></returns>
        public static int Build(MINUTIAE[]minutiae,int minuCount)
        {

            //定义变量
            const int max = 10;//最多保存10个相邻特征点
            int x1, x2, y1, y2;
            int[] pFlag = new int[minuCount];

            //遍历特征点数组
            for(int i = 0; i < minuCount; i++)
            {
                //获取当前特征点的信息
                x1 = minutiae[i].x;
                y1 = minutiae[i].y;

                //将自身标记为1
                pFlag[i] = 1;

                //为当前特征点创建并初始化相邻特征点结构数组
                minutiae[i].neibors = new NEIGHBOUR[max];
                if (minutiae[i].neibors == null)
                {
                    return -1;
                }

                //查找和保存10个相邻特征点
                for(int neiNo = 0; neiNo < max; neiNo++)
                {
                    //初始化最小间距和对应特征点下标
                    int minDis = 1000;//最小间距对应的下标
                    int minNo = 0;//最小间距对应的特征点下标

                    //查找相邻特征点之外的最近的不相邻的点
                    for(int j=0;j<minuCount;j++)
                    {
                        //跳过已找到的相邻特征点
                        if (pFlag[j] == 1)//0:不相邻；1：相邻
                        {
                            continue;
                        }

                        //获取特征点2的信息
                        x2 = minutiae[j].x;
                        y2 = minutiae[j].y;

                        //计算两点间距离
                        int r = (int)(Sqrt((float)((y1 - y2) * (y1 - y2) + (x1 - x2) * (x1 - x2))));

                        //查找最小间距
                        if (r < minDis)
                        {
                            minNo = j;
                            minDis = r;
                        }
                    }

                    //保存查找结果
                    pFlag[minNo] = 1;//将找到的最近的不相邻特征点标记设置为“相邻”
                    minutiae[i].neibors[neiNo].x = minutiae[minNo].x;//横坐标
                    minutiae[i].neibors[neiNo].y = minutiae[minNo].y;//纵坐标
                    minutiae[i].neibors[neiNo].type = minutiae[minNo].type;//特征点类型
                    minutiae[i].neibors[neiNo].Theta =Angle2Points(minutiae[minNo].x, minutiae[minNo].y,x1,y1);//两点连线角度
                    minutiae[i].neibors[neiNo].Theta2Ridge = minutiae[minNo].theta - minutiae[i].theta;//两点脊线方向夹角
                    minutiae[i].neibors[neiNo].ThetaThisNibor = minutiae[minNo].theta;//相邻特征点的脊线方向
                    minutiae[i].neibors[neiNo].distance = minDis;//两点距离

                }


            }

            return 0; 
        }

        public static float Angle2Points(int x1, int y1, int x2, int y2)
        {
            const float PI = 3.141592654f;
            float diffY, diffX;
            float theta = 0.0f;

            diffX = x2 - x1;
            diffY = y2 - y1;

            if (diffY < 0 && diffX > 0)
            {
                theta =(float) Atan2(-1 * diffY, diffX);
            }
            else if (diffY < 0 && diffX< 0)
            {
                theta =PI- (float)Atan2(-1 * diffY, -1*diffX);
            }
            else if (diffY > 0 && diffX < 0)
            {
                theta = (float)Atan2(diffY, -1 * diffX);
            }
            else if (diffY > 0 && diffX > 0)
            {
                theta =PI- (float)Atan2(diffY, diffX);
            }
            else if (diffX == 0)
            {
                theta = PI / 2;
            }
            else
            {
                theta = 0.0f;
            }
            return theta;
        }

        public static float MinuSim(int w,int h,MINUTIAE []minutiae1,int count1,MINUTIAE[]minutiae2,int count2)
        {
            const int maxSim_pair = 100;//最多保存100对配对相似特征点
            const int maxNei_each = 10;//每个特征点最多保存10个相邻特征点

            //构建相邻特征点关系
            Build(minutiae1, count1);
            Build(minutiae2, count2);

            //初始化特征点匹配结果（相似特征点点对）
            int[,] simPair = new int[maxSim_pair, 2];

            //选择基准特征和参考特征
            MINUTIAE[] baseMinutiae;//基准特征点数组（含特征点较少）
            MINUTIAE[] refMinutiae;//参考特征点数组（含特征点较多）
            int baseAccount, refAccount;
            if (count1 < count2)
            {
                baseAccount = count1;
                refAccount = count2;
                baseMinutiae = new MINUTIAE[baseAccount];
                refMinutiae = new MINUTIAE[refAccount];
                baseMinutiae = minutiae1;
                refMinutiae = minutiae2;
            }
            else
            {
                baseAccount = count2;
                refAccount = count1;
                baseMinutiae = new MINUTIAE[baseAccount];
                refMinutiae = new MINUTIAE[refAccount];
                baseMinutiae = minutiae2;
                refMinutiae = minutiae1;
            }
            //为方便起见，特征点均简称为点，如：基准点，参考点，相邻点，相似点等
            NEIGHBOUR[] baseNeighbors = new NEIGHBOUR[10];
            NEIGHBOUR[] refNeighbors = new NEIGHBOUR[10];

            int simMinu = 0;//相似点对数量
            float baseTheta, refTheta;//基准方向和参考方向
            for(int i = 0; i < baseAccount; i++)//逐一遍历基准点数组
            {
                //获取当前基准点信息
                baseNeighbors = baseMinutiae[i].neibors;
                baseTheta = baseMinutiae[i].theta;

                //在参考点数组中寻找与当前基准点最相似的参考点
                int refSimNo = 0;
                int maxSimNei = 0;
                for(int j = 0; j < refAccount; j++)
                {
                    //跳过与当前基准点类型不同的参考点
                    if (refMinutiae[j].type != baseMinutiae[i].type)
                    {
                        continue;
                    }
                    //获取当前参考点信息
                    refNeighbors = refMinutiae[j].neibors;
                    refTheta = refMinutiae[j].theta;

                    //统计相似相邻点数量
                    int thissimNei = 0;
                    for(int m = 0; m < maxNei_each; m++)
                    {
                        //在当前参考点的相邻点数组中查找与当前基准点的当前相邻点相似的相邻点
                        for(int n = 0; n < maxNei_each; n++)
                        {
                            //跳过类型不同的相邻点
                            if (baseNeighbors[m].type!=refNeighbors[n].type)
                            {
                                continue;
                            }
                            //计算两个相邻点之间的距离差和不同角度差
                            int dis = Abs((int)(baseNeighbors[m].distance - refNeighbors[n].distance));
                            float theta1 = Abs((float)(baseNeighbors[m].Theta - baseTheta)-(refNeighbors[n].Theta-refTheta));
                            float theta2= Abs((float)(baseNeighbors[m].Theta2Ridge - refNeighbors[n].Theta2Ridge));
                            float theta3= Abs((float)((baseNeighbors[m].Theta -baseNeighbors[m].ThetaThisNibor)- (refNeighbors[n].Theta-refNeighbors[n].ThetaThisNibor)));
                            //如果距离小于等于指定阈值（取4）并且角度差均小于指定阈值（取0.15），则认为这两个相邻点相似
                            if(dis<4&&theta1<0.15f && theta2 < 0.15f && theta3 < 0.15f)
                            {
                                ++thissimNei;
                                break;//转向当前基准点的下一个相邻点继续查找
                            }
                        }
                    }

                    //如果三对以上相邻点相似，则认为当前基准点与当前参考点相似，保存匹配接过
                    if ((thissimNei >= maxNei_each * 3 / 10) && (simMinu < maxSim_pair))
                    {
                        simPair[simMinu,0] = i;
                        simPair[simMinu, 1] = refSimNo;//保存当前参考下标
                        ++simMinu;//相似点对数量加1
                    }

                }

            }
            //计算特征匹配相似度
            float similarity = simMinu / 8.0f;
            //如果特征相似点数量小于指定下限阈值（取2），则认为完全不匹配
            similarity = simMinu < 2 ? 0.0f : similarity;//边界值处理
                                                         //如果特征相似点数量大于指定下限阈值（取8），则认为完全不匹配
            similarity = simMinu >8 ? 1.0f : similarity;//边界值处理
            return similarity; 
        }


    }
}
