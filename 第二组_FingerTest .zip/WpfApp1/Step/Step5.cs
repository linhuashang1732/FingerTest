﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.BaseOper;
using static System.Math;

namespace WpfApp1.Step
{
    class Step5
    {
        public static Bitmap Step_5(Bitmap bmp,float[]fDir,out float[]fFreqGet)//bmp：均衡化的图像
        {
            byte[] bytes = BaseClass.BmpToByte(bmp);
            int w = bmp.Width;
            int h = bmp.Height;
            fFreqGet = new float[w*h];
            Frequency(bytes,fDir,fFreqGet,w,h);
            for(int i = 0; i < bytes.Length; i++)
            {
                bytes[i]= (byte)(fFreqGet[i] * 1000);
            }
            Bitmap bm = BaseClass.BuiltGrayBitmap(bytes, bmp);
            return bm;

        }
        /// <summary>
        /// 频率计算
        /// </summary>
        /// <param name="bytes">均衡化处理图像转换的byte数组</param>
        /// <param name="fDire">方向计算结果数据</param>
        /// <param name="fFreq">频率计算数据</param>
        /// <param name="w"></param>
        /// <param name="h"></param>
        public static void Frequency(byte[] bytes,float[] fDire,float[]fFreq,int w,int h)
        {
            //窗口大小
            const int l1=32, w1=16, l2=16, w2=8;

            //正弦波峰值点
            int[] peak_pos=new int [l1];
            int peak_cnt;
            float peak_freq;
            float[] xsig = new float[l1];

            //方向
            float dir = 0.0f, cosdir = 0.0f, sindir = 0.0f, maxpeak, minpeak;

            //结果初始化
           float[] freq1 = new float[w * h];

            int x, y, d, k, u, v;

            for (y = l2; y < h - l2; y++)//逐行遍历，除边缘
            {
                for (x = l2; x < w - l2; x++)//逐列遍历，除边缘
                {
                    //当前脊线方向
                    dir = fDire[(y + w2) * w + (x + w2)];
                    cosdir =(float)( -Sin(dir));
                    sindir = (float)Cos(dir);//可能存在精度问题


                    //计算以当前像素为中心l1*w1邻域窗口的幅值序列X[0]-X[l1-1]
                    for (k = 0; k < l1; k++)
                    {
                        xsig[k] = 0.0f;
                        for (d = 0; d < w1; d++)
                        {
                            u = (int)(x + (d - w2) * cosdir + (k - l2) * sindir);
                            v = (int)(y + (d - w2) * sindir - (k - l2) * cosdir);
                            //边界点处理
                            if (u < 0) { u = 0; }
                            else if (u > w - 1) { u = w - 1; }
                            if (v < 0) { v = 0; }
                            else if (v > h - 1) { v = h - 1; }
                            xsig[k] +=(float) bytes[u + v * w];
                        }
                        xsig[k] /=(float) (w1 * 1.0);
                    }

                    //确定幅值序列变化范围
                    maxpeak = minpeak = xsig[0];
                    for (k = 0; k < l1; k++)
                    {
                        if (minpeak > xsig[k]) { minpeak = xsig[k]; }
                        if (maxpeak < xsig[k]) { maxpeak = xsig[k]; }
                    }

                    //确定峰值点位置
                    peak_cnt = 0;
                    if ((maxpeak - minpeak) > 64)
                    {
                        for (k = 1; k < l1-1; k++)
                        {
                            if (xsig[k - 1] < xsig[k] && xsig[k] >= xsig[k + 1])
                            {
                                peak_pos[peak_cnt++] = k;
                            }
                        }
                    }

                    //计算峰值点间平均距离
                    peak_freq = 0.0f;
                    if (peak_cnt >= 2)
                    {
                        for (k = 0; k < peak_cnt - 1; k++)
                        {
                            peak_freq += (peak_pos[k + 1] - peak_pos[k]);
                        }
                        peak_freq /= (float)((peak_cnt - 1) * 1.0);
                    }

                    //计算当前像素的频率
                    if (peak_freq < 3.0f || peak_freq > 25.0f)
                    {
                        freq1[x + y * w] = 0.0f;
                    }
                    else
                    {
                        freq1[x + y * w] =(float)( 1.0/peak_freq);
                    }
                }
            }

            //对频率进行均值滤波
            for (y = l2; y < h - l2; y++)//逐行遍历，除边缘
            {
                for (x = l2; x < w - l2; x++)//逐列遍历，除边缘
                {
                    k = x + y * w;//当前像素位置
                    peak_freq = 0.0f;
                    //使用以当前像素为中心的5*5邻域窗口进行均值滤波
                    for (v = -2; v <= 2; v++)
                    {
                        for (u = -2; u < 2; u++)
                        {
                            peak_freq += freq1[(x + u) + (y + v) * w];//求频率累加和
                        }
                    }
                    fFreq[k] =(float)( peak_freq / 25*1.0);//当前像素频率等于窗口内频率均值，空指针System.NullReferenceException:“未将对象引用设置到对象的实例。”

                }
            }
            //算法结束
                
        } 
     
    }
}

