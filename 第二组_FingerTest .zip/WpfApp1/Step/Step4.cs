﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WpfApp1.BaseOper;
using  static System.Math;

namespace WpfApp1.Step
{
    class Step4
    {
        public static Bitmap Step_4(Bitmap bmp, out float[] fFitDirc)
        {
            byte[] bytes = BaseClass.BmpToByte(bmp);
            int w = bmp.Width;
            int h = bmp.Height;
            float[] fDirc = new float[w * h];
            fFitDirc = new float[w*h];
            fDirc = ImgDirection(bytes, w, h);
            fFitDirc = DircLowPass(fDirc, w, h);
            for(int i = 0; i < fFitDirc.Length; i++)
            {
                bytes[i] = (byte)(fFitDirc[i] * 100);
            }
       
            Bitmap bm = BaseClass.BuiltGrayBitmap(bytes, bmp);
            return bm;
        } 
        /// <summary>
        /// 指纹脊线方向计算
        /// </summary>
        /// <param name="bytes"></param>
        /// <param name="w"></param>
        /// <param name="h"></param>
        public static float[] ImgDirection(byte[]bytes,int w,int h)
        {

            float[] fDirc = new float[w * h];
            int[] Intarr = Step3.byteToInt(bytes);
            const int WindowR = 7;//窗口半径
            int[,] dx = new int[WindowR * 2 + 1,WindowR * 2 + 1];
            int[,] dy = new int[WindowR * 2 + 1, WindowR * 2 + 1];
            float fx, fy;
            //计算每一像素的脊线方向
            for(int y = WindowR+1; y < h - WindowR - 1; y++)//逐行，除了边缘
            {
                for(int x = WindowR + 1; x < w - WindowR - 1; x++)//逐列，除了边缘
                {
                    for(int j = 0; j < WindowR * 2+1; j++)
                    {
                        for(int i = 0; i < WindowR * 2+1; i++)
                        {
                            int index1 = (y + j - WindowR) * w + x + i - WindowR;
                            int index2 = (y + j - WindowR) * w + x + i - WindowR-1;
                            int index3 = (y + j - WindowR-1) * w + x + i - WindowR;
                            dx[i,j] = Intarr[index1] - Intarr[index2];
                            dy[i, j] = Intarr[index1] - Intarr[index3];
                        }
                    }
                    //计算当前像素脊线方向值
                    fx = 0.0f;fy = 0.0f;
                    for(int j = 0; j < WindowR * 2+1; j++)
                    {
                        for(int i = 0; i < WindowR * 2+1; i++)
                        {
                            fx +=(float) (2 * dx[i, j] * dy[i, j] * 1.0);
                            fy += (float)((dx[i, j] * dx[i, j] - dy[i, j] * dy[i, j]) * 1.0);

                        }
                    }
                    fDirc[y * w + x] = (float)Math.Atan2(fx, fy);//此处转换可能存在精度问题
                }
            }
            return fDirc;
        }
       /// <summary>
       /// 脊线方向低通滤波
       /// <param name="fDirc"></param>
       /// <param name="w"></param> 
       /// <param name="h"></param>
       /// <returns></returns>
        public static float[] DircLowPass(float[]fDirc,int w,int h)
        {
            int arrsize = w * h;
            float[] fFitDirc = new float[arrsize];
            const int fisize = 2;
            int blocksize = 2 * fisize + 1;
            float[] filter = new float[blocksize*blocksize];
            float[] phix = new float[arrsize];
            float[] phiy = new float[arrsize];
            float[] phi2x = new float[arrsize];
            float[] phi2y = new float[arrsize];
            float sum = 0.0f;
            for(int y = 0; y < blocksize; y++)
            {
                for(int x = 0; x < blocksize; x++)
                {
                    filter[y * blocksize + x] = (float)(blocksize - Math.Abs(fisize - x) + Math.Abs(fisize - y));
                    sum += filter[y * blocksize + x];
                }
            }
            for(int y = 0; y < blocksize; y++)
            {
                for(int x = 0; x < blocksize; x++)
                {
                    filter[y * blocksize + x] /= sum;
                }
            }
            //计算各像素点的方向正弦值，余弦值
            for(int y = 0; y < h; y++)
            {
                for(int x = 0; x < w; x++)
                {
                    phix[y * w + x] =(float) Cos(fDirc[y * w + x]);
                    phiy[y * w + x] = (float)Sin(fDirc[y * w + x]);
                }
            }
            //对所有像素进行低通滤波
            float nx, ny;
            int val;
            for(int y = 0; y < h - blocksize; y++)
            {
                for(int x = 0;x < w - blocksize; x++)
                {
                    nx = 0.0f;ny = 0.0f;
                    for(int j = 0; j < blocksize; j++)
                    {
                        for(int i = 0; i < blocksize; i++)
                        {
                            val = (x + i) + (j + y) * w;
                            nx += filter[j * blocksize + i] * phix[val];
                            ny+= filter[j * blocksize + i] * phiy[val];
                        }
                    }
                    val = x + y * w;
                    phi2x[val] = nx;
                    phi2y[val] = ny;
                }
            }
            //根据加权累加累加结果，计算各像素的方向滤波结果值
            for(int y= 0; y< h - blocksize; y++)
            {
                for (int x = 0; x < w - blocksize; x++)
                {
                    val = x + y * w;
                    fFitDirc[val] = (float)(Atan2(phi2y[val], phi2x[val]) * 0.5);
            }
            }
           
            return fFitDirc;
        }
        
    
    }
}
