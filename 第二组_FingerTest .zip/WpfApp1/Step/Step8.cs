﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.BaseOper;

namespace WpfApp1.Step
{
    class Step8
    {


        /// <summary>
        /// 
        /// </summary>
        /// <param name="bmp">均衡化的图像</param>
        /// <param name="uThreshold">阈值</param>
        /// <param name="ucBinImage">结果byte数组（值为0或1）</param>
        /// <returns></returns>
        public static Bitmap Step_8(Bitmap bmp,byte uThreshold,out byte[]ucBinImage )//bmp：均衡化的图像
        {
            byte[] bytes = BaseClass.BmpToByte(bmp);
            int w = bmp.Width;
            int h = bmp.Height;
            ucBinImage = new byte[w * h];
           for(int i = 0; i < bytes.Length; i++)
            {
                if (bytes[i] <= uThreshold)
                {
                    ucBinImage[i] = 0;
                }
                else
                {
                    ucBinImage[i] = 1;
                }
            }
            byte[] bytesCopy = new byte[w * h];
            for(int i = 0; i < bytesCopy.Length; i++)
            {
                if (ucBinImage[i] == 0)
                {
                    bytesCopy[i] = 0;
                }
                else
                {
                    bytesCopy[i] = 255;
                }
            }
            Bitmap bm = BaseClass.BuiltGrayBitmap(bytesCopy, bmp);
            return bm;

        }
    }
}
