﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WpfApp1.BaseOper;

namespace WpfApp1.Step
{
    class Step6
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="bmp">均衡化后的图像</param>
        /// <param name="fDir">脊线方向数据</param>
        /// <param name="fFreqGet">脊线频率数据</param>
        /// <param name="ucMask">掩码数据</param>
        /// <returns></returns>
        public static Bitmap Step_6(Bitmap bmp, float[] fDir, float[] fFreqGet, out byte[] ucMask)//bmp：均衡化的图像
        {
            byte[] bytes = BaseClass.BmpToByte(bmp);
            int w = bmp.Width;
            int h = bmp.Height;
            
            ucMask = new byte[w * h];
          
            GetMask(bytes, w, h, fDir, fFreqGet, out ucMask);
            Bitmap bm = BaseClass.BuiltGrayBitmap(ucMask, bmp);
            return bm;

        }
        public static void GetMask(byte[] bytes, int w, int h,float[] fDir, float[] fFreq, out byte[] ucMask)
        {

            ucMask = new byte[bytes.Length];
            //阈值分割
            float freqMin = (float)(1.0 / 25.0);
            float freqMax = (float)(1.0 / 3.0);
            int x, y, k;
            int pos, posout;
            for (int i = 0; i < ucMask.Length; i++)
            {
                ucMask[i] = 0;
            }

            for (y = 0; y < h; y++)
            {
                for (x = 0; x < w; x++)
                {
                      pos = x + y * w;
                    posout = x + y * w;
                    ucMask[posout] = 0;
                    if (fFreq[pos] >= freqMin && fFreq[pos] <= freqMax)
                    {
                        ucMask[posout] = 255;
                    }
                }
            }

            //第二步：填充孔洞
            for (k = 0; k < 4; k++)//重复膨胀多次，可自定
            {
                //标记前景点
                for (y = 1; y < h - 1; y++)
                {
                    for (x = 1; x < w - 1; x++)
                    {
                        //前景点的上下左右四个相邻点都标记为前景点
                        if (ucMask[x + y * w] == 0xFF)//前景点
                        {
                            ucMask[x - 1 + y * w] |= 0x80;
                            ucMask[x + 1 + y * w] |= 0x80;
                            ucMask[x + (y - 1) * w] |= 0x80;
                            ucMask[x + (y + 1) * w] |= 0x80;
                        }
                    }

                }
                //判断和设置前景点
                for (y = 1; y < h - 1; y++)
                {
                    for (x = 1; x < w - 1; x++)
                    {
                        //将标记前景点的的像素都设为前景点
                        if (ucMask[x + y * w] != 0x0)//前景点
                        {
                            ucMask[x + y * w] = 0xFF;//设置为前景点
                        }
                    }

                }
            }

            //第三步：去除边缘点和孤立点
            for (k = 0; k < 12; k++)//重复腐蚀多次，可自定
            {
                //标记背景点
                for (y = 1; y < h - 1; y++)
                {
                    for (x = 1; x < w - 1; x++)
                    {
                        //前景点的上下左右四个相邻点都标记为潜在背景点
                        if (ucMask[x + y * w] == 0x0)//前景点
                        {
                            ucMask[x - 1 + y * w] &= 0x80;
                            ucMask[x + 1 + y * w] &= 0x80;
                            ucMask[x + (y - 1) * w] &= 0x80;
                            ucMask[x + (y + 1) * w] &= 0x80;
                        }
                    }

                }
                //判断和设置背景点
                for (y = 1; y < h - 1; y++)
                {
                    for (x = 1; x < w - 1; x++)
                    {
                        //前景点的上下左右四个相邻点都标记为前景点
                        if (ucMask[x + y * w] != 0xFF)//前景点
                        {
                            ucMask[x + y * w] |= 0x0;
                        }
                    }

                }
            }
        }
    }
}
