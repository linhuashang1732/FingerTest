﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.BaseOper;

namespace WpfApp1.Step
{
    class Step3
    {
        public static Bitmap Step_3(Bitmap bmp)//指纹处理算法方法名按照Step_3（Bitmap bmp）这种格式
        {
            /////////////////////////////////////
            ///  byte[] bytes = BaseClass.BmpToByte(bmp);
            ///  将bitmap对象中的像素值读入bytes数组中
            ///int w = oriImage.Width;
            ///图像的宽度获取
            ///int h = oriImage.Height;
            ///图像的高度获取
            ///此处没有下面的语句
            ///byte[,] xy = new byte[h, w];
            ///直方图均衡化不需要转换即可直观的完成。再次声明：转换与否根据实际需要
            ////////////////////////////////////
            byte[] bytes = BaseClass.BmpToByte(bmp);
            int w = bmp.Width;
            int h = bmp.Height;
            //bytes 转为 Intarr，便于求值
            int[] Intarr = byteToInt(bytes);
            int sum = Intarr.Sum();
            //求平均值
            //double dMean = sum / Intarr.Length ;sum,Intarr.Length均为整形，二者相除得到结果也为整形，不会有小数
            //而dMean为double，要想保留小数，需在上式后面乘上1.0（1.0：double类型）；
            double dMean = sum / Intarr.Length * 1.0;
            //求方差
            double dSigma = 0;
            for(int i = 0; i < Intarr.Length; i++)
            {
                dSigma += (Intarr[i] - dMean) * (Intarr[i] - dMean);
            }
            dSigma = dSigma / Intarr.Length * 1.0;
            dSigma = Math.Sqrt(dSigma);
            //均衡化
            double dMean0 = 128, dSigma0 = 128;//预设灰度均值和方差
            double dCoeff = dSigma0 / dSigma;//预设转换系数
            for(int i = 0; i < Intarr.Length; i++)
            {
                double dValue = (double)Intarr[i];
                dValue=dMean0+dCoeff*(dValue-dMean0);
                if (dValue < 0)
                {
                    dValue = 0;
                }
                else if (dValue > 255)
                {
                    dValue = 255;
                }
                Intarr[i] = (int)dValue;
            }
            //Intarr转为bytes
            bytes = IntTobyte(Intarr);
            //由bytes生成bitmap
            Bitmap bt = BaseClass.BuiltGrayBitmap(bytes, bmp);
            return bt;

        }
        /// <summary>
        /// byte数组转为int数组
        /// 原因：byte不是整形，直接进行加减乘除可能出错
        /// 为避免此问题，转为整形
        /// </summary>
        /// <param name="bytes"></param>
        /// <returns></returns>
        public static int[] byteToInt(byte[] bytes)
        {
            int[] Intarr = new int[bytes.Length];

            for(int i=0;i<bytes.Length;i++)
            {
                Intarr[i] = (int)bytes[i];
            }
            return Intarr;
        }
       /// <summary>
       /// 整形数组操作后，转换为bytes，便于保存为bitmap
       /// </summary>
       /// <param name="Intarr"></param>
       /// <returns></returns>
        public static byte[] IntTobyte(int[] Intarr)
        {
            byte[] bytes = new byte[Intarr.Length];
            for(int i = 0; i< Intarr.Length; i++){
                bytes[i] =(byte) Intarr[i];
            }
            return bytes;

        }
    }
}
