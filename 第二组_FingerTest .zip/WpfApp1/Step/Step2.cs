﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.BaseOper;

namespace WpfApp1.Step
{
    class Step2
    {
        public static Bitmap Step_2(Bitmap bmp)//指纹处理算法方法名按照Step_2（Bitmap bmp）这种格式
        {
            //MemoryStream ms = new MemoryStream();
            //oriImage.Save(ms, System.Drawing.Imaging.ImageFormat.Bmp);
            //byte[] bytes;

            //bytes = ms.GetBuffer();
            /////////////////////////////////////
            ///  byte[] bytes = BaseClass.BmpToByte(oriImage);
            ///  将bitmap对象中的像素值读入bytes数组中
            ///int w = oriImage.Width;
            ///图像的宽度获取
            ///int h = oriImage.Height;
            ///图像的高度获取
            ///byte[,] xy = new byte[h, w];
            ///这个二维数组由bytes转化而来，便于处理类似于中值滤波的问题。转换与否根据需要
            ////////////////////////////////////
            byte[] bytes = BaseClass.BmpToByte(bmp);
            int w =bmp.Width;
            int h =bmp.Height;
            byte[,] xy = new byte[h,w];
            for(int i = 0; i < h; i++)
            {
                for(int j = 0; j < w; j++)
                {
                    xy[i, j] = bytes[i * w + j];
                }
            }
            byte[] x = new byte[9];
            for(int i = 1; i < h - 1; i++)
            {
                for(int j = 1; j < w - 1; j++)
                {
                    x[0] = xy[i - 1, j - 1];
                    x[1]= xy[i - 1, j ];
                    x[2]=xy[i - 1, j + 1];
                    x[3] = xy[i , j - 1];
                    x[4] = xy[i, j];
                    x[5] = xy[i, j + 1];
                    x[6] = xy[i +1, j - 1];
                    x[7] = xy[i +1, j];
                    x[8] = xy[i + 1, j + 1];
                    Array.Sort(x);
                    xy[i, j] = x[4];
                }
               
            }
            byte[] x1 = new byte[6];
            //第一行
            for(int j = 1; j < w-1; j++)
            {
                x1[0] = xy[0, j - 1];
                x1[1] = xy[0, j];
                x1[2] = xy[0, j + 1];
                x1[3] = xy[1, j - 1];
                x1[4] = xy[1, j];
                x1[5] = xy[1, j + 1];
                Array.Sort(x1);
                xy[0, j] = x1[3];
            }
            //最后一行
            for (int j = 1; j < w - 1; j++)
            {
                x1[0] = xy[h-2, j - 1];
                x1[1] = xy[h - 2, j];
                x1[2] = xy[h - 2, j+ 1];
                x1[3] = xy[h-1, j - 1];
                x1[4] = xy[h-1, j];
                x1[5] = xy[h-1, j + 1];
                Array.Sort(x1);
                xy[h-1, j] = x1[3];
            }
            //四角
            byte[] x2 = new byte[4];
            //左上
            x[0] = xy[0, 0];
            x[1] = xy[0, 1];
            x[2] = xy[1, 0];
            x[3]= xy[1, 1];
            Array.Sort(x2);
            xy[0, 0] = x2[2];
            //左上
            x[0] = xy[0, 0];
            x[1] = xy[0, 1];
            x[2] = xy[1, 0];
            x[3] = xy[1, 1];
            Array.Sort(x2);
            xy[0, 0] = x2[2];
            //右上
            x[0] = xy[0, w-2];
            x[1] = xy[0, w-1];
            x[2] = xy[1, w-2];
            x[3] = xy[1, w-1];
            Array.Sort(x2);
            xy[0, w-1] = x2[2];
            //左下
            x[0] = xy[h-2, 0];
            x[1] = xy[h-2, 1];
            x[2] = xy[h-1, 0];
            x[3] = xy[h-1, 1];
            Array.Sort(x2);
            xy[h-1, 0] = x2[2];
            //右下
            x[0] = xy[h - 2, w-2];
            x[1] = xy[h - 2, w-1];
            x[2] = xy[h - 1, w-2];
            x[3] = xy[h - 1, w-1];
            Array.Sort(x2);
            xy[h - 1, w-1] = x2[2];
            for (int i = 0; i < h; i++)
            {
                for (int j = 0; j < w; j++)
                {
                    bytes[i * w + j] = xy[i, j];
                }
            }
            //////////////////////
            /// Bitmap bt = BaseClass.BuiltGrayBitmap(bytes,oriImage);
            /// 将处理后的bytes数组数据转换为bitmap对象返回
            ///////////////////////
            Bitmap bt = BaseClass.BuiltGrayBitmap(bytes,bmp);
            return bt;
        }
    }
}
