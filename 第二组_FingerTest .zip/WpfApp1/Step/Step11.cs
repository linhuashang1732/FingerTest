﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.BaseOper;
using static System.Math;

namespace WpfApp1.Step
{
    class Step11
    {
        [Serializable]
        public struct NEIGHBOUR 
        {
           public int x;
           public  int y;//横纵坐标
           public  int type;//特征点类型（1：端点；3：分叉点）
           public float Theta;//两点连线角度（弧度）
           public float Theta2Ridge;//两点脊线方向夹角（弧度）
           public  float ThetaThisNibor;//相邻特征点的脊线方向（弧度）
           public int distance;//两点距离（像素数量）

        };
        [Serializable]
        public struct MINUTIAE 
        {
          public  int x; 
          public  int y;//横纵坐标
          public int type;//特征点类型（1：端点；3：分叉点）
          public float theta;//该点处脊线方向（弧度）
          public  NEIGHBOUR []neibors;//相邻点特征序列
        };

        /// <summary>
        /// 
        /// </summary>
        /// <param name="bmp">均衡化图像：主要用于获取w，h</param>
        /// <param name="ucthinDat">细化数据</param>
        /// <param name="minuData">特征数据</param>
        /// <param name="minutiaes">特征点数组</param>
        /// <param name="minuCount">特征点数量</param>
        /// <returns></returns>
        public static Bitmap Step_11(Bitmap bmp, byte[] thinData, byte[] minuData, out MINUTIAE[] minutiaes, ref int minuCount)//bmp：均衡化的图像
        {
            int w = bmp.Width;
            int h = bmp.Height;
            MinuFilter(w, h,thinData,  minuData, out minutiaes, ref minuCount);
            byte[] bytesCopy = new byte[w * h];
            for (int i = 0; i < bytesCopy.Length; i++)
            {
                bytesCopy[i] = 0;
            }
            for (int i = 0; i < minuCount; i++)
            {
                bytesCopy[(minutiaes[i].y - 1) * w + (minutiaes[i].x - 1)] = 255;
            }
            Bitmap bm = BaseClass.BuiltGrayBitmap(bytesCopy, bmp);
         
            return bm;

        }

        public static void MinuFilter(int w, int h, byte[] thinData,  byte[] minuData, out MINUTIAE[] minutiaes, ref int minuCount)
        {
            //1.计算细化图中各点方向
            float[] dir = new float[w * h];
            minutiaes = new MINUTIAE[w * h];
            dir =Step4.ImgDirection(thinData, w, h);
            //2.从特征图中提取特征点数据
            int pImg;
            byte val;
            int temp = 0;
            for(int i = 1; i < h - 1; i++)
            {
                pImg = i * w;
                for(int j = 1; j < w - 1; j++)
                {
                    //获取特征图数据
                    pImg++;
                    val = minuData[pImg];
                    //提取特征点数据
                    if (val > 0)
                    {
                        minutiaes[temp].x = j + 1;
                        minutiaes[temp].y = i + 1;
                        minutiaes[temp].theta = dir[i*w+j];//脊线方向
                        minutiaes[temp].type = (int)val;
                        temp++;
                    }

                }
            }
            Array.Copy(minutiaes, minutiaes, temp);
            //第三步：去除边缘特征点
            minuCount = cutEdge(minutiaes, minuCount, thinData, w, h);

            //第四步：去除毛刺、小孔，间断等伪特征点
            int[] pFlag = new int[minuCount];//0:保留；1：删除；

            //遍历所有特征点
            int x1,x2,y1,y2,type1,type2;
            for(int i = 0; i < minuCount; i++)//特征点1遍历
            {
                //获取特征点1的数据
                x1 = minutiaes[i].x;
                y1 = minutiaes[i].y;
                type1 = minutiaes[i].type;//特征点类型
                for(int j=i+1;j<minuCount;j++)//遍历特征点2
                {
                    //跳过已删特征点
                    if (pFlag[j] == 1)
                    {
                        continue;
                    }
                    //获取特征点2的数据
                    x2 = minutiaes[j].x;
                    y2 = minutiaes[j].y;
                    type2 = minutiaes[j].type;//特征点类型
                    //计算两点间间距
                    int r = (int)(Sqrt((float)((y1-y2)*(y1-y2)+(x1-x2)*(x1-x2))));
                    //删除间距过小的特征点
                    if (r <= 4)//距离小于5删除
                    {
                        if(type1==type2)//二者类型相同
                        {
                            if (type1 == 1)
                            {
                                pFlag[i] = pFlag[j] = 1;//同时删掉两点
                            }
                            else//两点均为分叉点，则认定为小孔
                            {
                                pFlag[j] = 1;//只删除点2
                            }
                        }
                        else if (type1 == 1)//1为端点，2为分叉点，则1为毛刺
                        {
                            pFlag[i] = 1;
                        }
                        else//2为毛刺
                        {
                            pFlag[j] = 1;
                        }
                    }
                }
                    
            }

            //重组特征点结构数组
            int newCount = 0;//有效特征点数量
            for(int i = 0; i < minuCount; i++)
            {
               
                if (pFlag[i] == 0)
                {
                    minutiaes[newCount] = minutiaes[i];
                    newCount++;
                }
            }
            minuCount = newCount;//保存有效特征点数量
            Array.Copy(minutiaes, minutiaes, minuCount);
        }

        private static int cutEdge(MINUTIAE[] minutiaes, int count, byte[] thinData, int w, int h)
        {
            //定义变量
            int minuCount = count;
            int x, y, type;
            bool del;

            //初始化标记数组
            int[] pFlag = new int[minuCount];

            //遍历所有特征点
            for(int i = 0; i < minuCount; i++)
            {
                //获取当前特征点信息
                y = minutiaes[i].y - 1;
                x = minutiaes[i].x - 1;
                type = minutiaes[i].type;

                //将当前特征点删除标记初始化为true
                del = true;

                //根据当前特征点位置判断是否为边远特征点
                if(x<w/2)//位于左半图
                {
                    if(Abs(w/2-x)>Abs(h/2-2))//位于左半图左侧
                    {
                        //在特征图中查找当前特征点同一行左侧是否还有其它特征点
                        while (--x>=0)//逐一左移查找
                        {
                            //如果在左侧存在其他特征点，则说明当前特征点不是边缘特征点，无须删除
                            if (thinData[x + y * w] > 0)
                            {
                                del = false;
                                break;
                            }
                        }
                    }
                    else//左半图右侧
                    {
                        if (y > h / 2)//右下侧
                        {
                            while (++y < h)
                            {
                                if (thinData[x + y * w] > 0)
                                {
                                    del = false;
                                    break;
                                }
                            }
                        }
                        else//位于右上侧
                        {
                            while (--y>=0)
                            {
                                if (thinData[x + y * w] > 0)
                                {
                                    del = false;
                                    break;
                                }
                            }
                        }
                    }
                }
                //如果位于图像右半图
                else
                {
                    if(Abs(w/2-x)>Abs(h/2-y))//右侧
                    {
                        while (++x < w)
                        {
                            if (thinData[x + y * w] > 0)
                            {
                                del = false;
                                break;
                            }
                        }
                    }
                    else//左侧
                    {
                        if (y > h / 2)//左下侧
                        {
                            while (++y < h)
                            {
                                if (thinData[x + y * w] > 0)
                                {
                                    del = false;
                                    break;
                                }
                            }
                        }
                        else//左上侧
                        {
                            while (--y >=0)
                            {
                                if (thinData[x + y * w] > 0)
                                {
                                    del = false;
                                    break;
                                }
                            }
                        }
                    }
                }

                //如果当前特征点是边缘特征点，则予以删除
                if (del)
                {
                    pFlag[i] = 1;
                    continue;
                }
            }

            //重组特征点结构数组
            int newCount = 0;
            for(int i = 0; i < minuCount; i++)
            {
                if (pFlag[i] == 0)
                {
                    minutiaes[newCount] = minutiaes[i];
                    newCount++;
                }
            }
            Array.Copy(minutiaes, minutiaes, newCount);//此处可能存在问题
            pFlag = null;
            return newCount;

        }
    }
}
