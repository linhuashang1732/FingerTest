﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.BaseOper;
using static System.Math;

namespace WpfApp1.Step
{
    class Step9
    {
        //C++中非零为真
        /// <summary>
        /// 
        /// </summary>
        /// <param name="bmp">返回图像</param>
        /// <param name="ucBinImage">二值化数据</param>
        /// <param name="ucThinnedImage">细化数据</param>
        /// <param name="count">迭代次数</param>
        /// <returns></returns>
        public static Bitmap Step_9(Bitmap bmp, byte[] ucBinImage, out byte[]ucThinnedImage,int count)//bmp：均衡化的图像
        {
            int w = bmp.Width;
            int h = bmp.Height;
           
            Thining(w,h,count,ucBinImage,out ucThinnedImage);
            byte[] bytesCopy = new byte[w * h];
            for (int i = 0; i < bytesCopy.Length; i++)
            {
                if (ucThinnedImage[i] == 0)
                {
                    bytesCopy[i] = 0;
                }
                else
                {
                    bytesCopy[i] = 255;
                }
            }
            Bitmap bm = BaseClass.BuiltGrayBitmap(bytesCopy, bmp);
            return bm;

        }

        private static void Thining(int w,int h,int count,byte[]ucBinImage,out byte[]ucThinnedImage)
        {
            byte x1, x2, x3, x4, x5, x6, x7, x8, xp;
            byte g1, g2, g3, g4;
            byte b1=0, b2=0, b3=0, b4=0;
            byte np1, np2, npm;
            int pUp, pDown, pImg;
            int iDlePoints = 0;

            ucThinnedImage = new byte[w * h];
            Array.Copy(ucBinImage, ucThinnedImage, w * h);
            //byte[,] byte2D = new byte[h, w];
            //for(int i = 0; i < h; i++)
            //{
            //    for(int j = 0; j < w; j++)
            //    {
            //        byte2D[i, j] = ucBinImage[j + i * w];
            //    }
            //}
            for(int it = 0; it < count; it++)
            {
                iDlePoints = 0;//初始化本次迭代删除点数

                //本次迭代的第一次遍历
                for(int i = 1; i < h - 1; i++)//逐行遍历
                {
                    pUp = (i - 1) * w;
                    pImg = i * w;
                    pDown = (i + 1) * w;
                    for(int j = 1; j < w - 1; j++)//=逐列遍历
                    {
                        pUp++;
                        pImg++;
                        pDown++;
                        if (ucThinnedImage[pImg] == 0)
                        {
                            continue;
                        }
                        //获取3*3邻域窗口内9个像素的灰度值
                        x6 = ucThinnedImage[pUp - 1];
                        x5 = ucThinnedImage[pImg - 1];
                        x4 = ucThinnedImage[pDown - 1];

                        x7 = ucThinnedImage[pUp];
                        xp = ucThinnedImage[pImg];
                        x3 = ucThinnedImage[pDown];

                        x8 = ucThinnedImage[pUp + 1];
                        x1 = ucThinnedImage[pImg + 1];
                        x2 = ucThinnedImage[pDown + 1];

                        //判断条件G1
                       if(x1==0 && (x2 == 1 || x3 == 1))      b1 = 1;
                       else  b1 = 0;

                        if (x3 == 0 && (x4 == 1 || x5 == 1))  b2 = 1;
                        else b2= 0;

                        if (x5 == 0 && (x6 == 1 || x7 == 1))  b3 = 1;
                        else b3 = 0;
                        
                        if (x7 == 0 && (x8 == 1 || x1 == 1))  b4 = 1;
                        else b4 = 0;
                        
                        if (b1 + b2 + b3 + b4 != 0)           g1 = 1;
                        else g1 = 0;

                        //判断条件g2
                        if (x1 + x2 != 0) np1 = 1;
                        else np1 = 0;
                        if (x3 + x4 != 0) np1++;
                        if (x5 + x6 != 0) np1++;
                        if (x7 + x8 != 0) np1++;

                        if (x2 + x3 != 0) np2 = 1;
                        else np2 = 0;
                        if (x4 + x5 != 0) np2++;
                        if (x7 + x6 != 0) np2++;
                        if (x1 + x8 != 0) np2++;

                        npm = np1 > np2 ? np2 : np1;
                        if (npm >= 2 && npm <= 3) g2 = 1;
                        else g2 = 0;
                        //判断g3，g4
                        int temp;
                        if (x1 != 0 && (x2 != 0 || x3 != 0 || x8 != 1)) temp = 1;
                        else temp = 0;
                        if (temp == 0) g3 = 1;
                        else g3 = 0;
                        int temp1;
                        if (x5 != 0 && (x6 != 0 || x7 != 0 || x4 != 1)) temp1 = 1;
                        else temp1 = 0;
                        if (temp1 == 0) g4 = 1;
                        else g4 = 0;
                        //组合判断
                        if (g1 != 0 && g2 != 0 && g3 != 0)
                        {
                            ucThinnedImage[w * i + j] = 0;
                            ++iDlePoints;
                        }
                    }
                }

                //结果同步
                Array.Copy(ucThinnedImage, ucBinImage, w * h);
                //迭代第二次遍历
                for(int i = 1; i < h - 1; i++)
                {
                    pUp = (i - 1) * w;
                    pImg = i * w;
                    pDown = (i + 1) * w;
                    for (int j = 1;j< w - 1; j++)
                    {
                        pUp++;
                        pImg++;
                        pDown++;
                        if (ucThinnedImage[pImg] == 0)
                        {
                            continue;
                        }
                        //获取3*3邻域窗口内9个像素的灰度值
                        x6 = ucThinnedImage[pUp - 1];
                        x5 = ucThinnedImage[pImg - 1];
                        x4 = ucThinnedImage[pDown - 1];

                        x7 = ucThinnedImage[pUp];
                        xp = ucThinnedImage[pImg];
                        x3 = ucThinnedImage[pDown];

                        x8 = ucThinnedImage[pUp + 1];
                        x1 = ucThinnedImage[pImg + 1];
                        x2 = ucThinnedImage[pDown + 1];

                        //判断条件G1
                        if (x1 == 0 && (x2 == 1 || x3 == 1)) b1 = 1;
                        else b1 = 0;

                        if (x3 == 0 && (x4 == 1 || x5 == 1)) b2 = 1;
                        else b2 = 0;

                        if (x5 == 0 && (x6 == 1 || x7 == 1)) b3 = 1;
                        else b3 = 0;

                        if (x7 == 0 && (x8 == 1 || x1 == 1)) b4 = 1;
                        else b4 = 0;

                        if (b1 + b2 + b3 + b4 != 0) g1 = 1;
                        else g1 = 0;

                        //判断条件g2
                        if (x1 + x2 != 0) np1 = 1;
                        else np1 = 0;
                        if (x3 + x4 != 0) np1++;
                        if (x5 + x6 != 0) np1++;
                        if (x7 + x8 != 0) np1++;

                        if (x2 + x3 != 0) np2 = 1;
                        else np2 = 0;
                        if (x4 + x5 != 0) np2++;
                        if (x7 + x6 != 0) np2++;
                        if (x1 + x8 != 0) np2++;

                        npm = np1 > np2 ? np2 : np1;
                        if (npm >= 2 && npm <= 3) g2 = 1;
                        else g2 = 0;
                        //判断g3，g4
                        int temp;
                        if (x1 != 0 && (x2 != 0 || x3 != 0 || x8 != 1)) temp = 1;
                        else temp = 0;
                        if (temp == 0) g3 = 1;
                        else g3 = 0;
                        int temp1;
                        if (x5 != 0 && (x6 != 0 || x7 != 0 || x4 != 1)) temp1 = 1;
                        else temp1 = 0;
                        if (temp1 == 0) g4 = 1;
                        else g4 = 0;
                        //组合判断
                        if (g1 != 0 && g2 != 0 && g4 != 0)
                        {
                            ucThinnedImage[w * i + j] = 0;
                            ++iDlePoints;
                        }
                    }
                }
                //结果同步
                Array.Copy(ucThinnedImage, ucBinImage, w * h);
                //若本次迭代无点可删除，停止迭代
                if (iDlePoints == 0)//
                {
                    break;
                }
            }
            //清除边缘区段
            for(int i = 0; i < w; i++)
            {
                for(int j=0; j < w; j++)
                {
                    if (i < 16)//上边缘
                        ucThinnedImage[i * w + j] = 0;
                    else if(i>=h-16)//下边缘
                        ucThinnedImage[i * w + j] = 0;
                    else if(j<16)//左边缘
                        ucThinnedImage[i * w + j] = 0;
                    else if(j>=w-16)//右边缘
                        ucThinnedImage[i * w + j] = 0;
                }
            }
        }
    }
}
