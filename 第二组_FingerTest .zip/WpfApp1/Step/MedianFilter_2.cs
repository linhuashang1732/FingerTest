﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace WpfApp1.图像处理
{
    class MedianFilter
    {
        public static Bitmap MedFilter(Bitmap oriImage)
        {
            int width = oriImage.Width;
            int height = oriImage.Height;
            BitmapData oriImageData = oriImage.LockBits(new Rectangle(0, 0, width, height), ImageLockMode.ReadWrite, PixelFormat.Format8bppIndexed);
            //创建新的bitmap存放滤波后的图
            Bitmap newImage = new Bitmap(width, height, PixelFormat.Format8bppIndexed);
            BitmapData newImageData = newImage.LockBits(new Rectangle(0, 0, width, height), ImageLockMode.ReadWrite, PixelFormat.Format8bppIndexed);

            IntPtr intPtrN = newImageData.Scan0;
            IntPtr intPtr = oriImageData.Scan0;
            int size = oriImageData.Stride * height;
            byte[] oriBytes = new byte[size];
            byte[] newBytes = new byte[size];
            Marshal.Copy(intPtr, oriBytes, 0, size);
            //先复制一份原图的数据到滤波数组中
            Marshal.Copy(intPtr, newBytes, 0, size);
            int[] mask = new int[9];

            int k = 3;
            for (int y = 0; y < height - 2; y++)
            {
                for (int x = 0; x < width - 2; x++)
                {
                    mask[0] = oriBytes[y * oriImageData.Stride + x];
                    mask[1] = oriBytes[y * oriImageData.Stride + x + 1];
                    mask[2] = oriBytes[y * oriImageData.Stride + x + 2];

                    mask[3] = oriBytes[(y + 1) * oriImageData.Stride + x];
                    mask[4] = oriBytes[(y + 1) * oriImageData.Stride + x + 1];
                    mask[5] = oriBytes[(y + 1) * oriImageData.Stride + x + 2];

                    mask[6] = oriBytes[(y + 2) * oriImageData.Stride + x];
                    mask[7] = oriBytes[(y + 2) * oriImageData.Stride + x + 1];
                    mask[8] = oriBytes[(y + 2) * oriImageData.Stride + x + 2];

                    Array.Sort(mask);
                    int median = mask[4];

                    //newImageData.Stride 是等于 oriImageData.Stride 的
                    newBytes[(y + 1) * oriImageData.Stride + x + 1] = (byte)median;


                }
            }
            Marshal.Copy(newBytes, 0, intPtrN, size);
            oriImage.UnlockBits(oriImageData);
            newImage.UnlockBits(newImageData);

            return newImage;
        }
        }
    }
